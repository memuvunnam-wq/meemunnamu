export const environment = {
  production: true,
  apiUrl: 'https://api.meemunnamu.org/api',
  useMockData: true // Safe standalone default until backend server is deployed
};

