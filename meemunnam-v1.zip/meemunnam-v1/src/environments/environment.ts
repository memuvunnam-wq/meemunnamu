export const environment = {
  production: false,
  apiUrl: 'http://localhost:3000/api', // Backend REST API endpoint for local development
  useMockData: true // Set to false when backend API is connected
};

