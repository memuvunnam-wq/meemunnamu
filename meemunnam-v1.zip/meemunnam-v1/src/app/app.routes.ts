import { Routes } from '@angular/router';
import { MainLayoutComponent } from './layout/main-layout/main-layout.component';

export const routes: Routes = [
  {
    path: '',
    component: MainLayoutComponent,
    children: [
      {
        path: '',
        loadComponent: () => import('./features/home/home.component').then(m => m.HomeComponent),
        title: 'Memu Vunnam Foundation | Together We Support, Together We Transform Lives'
      },
      {
        path: 'about',
        loadComponent: () => import('./features/about/about.component').then(m => m.AboutComponent),
        title: 'About Us | Memu Vunnam Foundation'
      },
      {
        path: 'programs',
        loadComponent: () => import('./features/programs/programs.component').then(m => m.ProgramsComponent),
        title: 'Our Programs & Focus Areas | Memu Vunnam Foundation'
      },
      {
        path: 'programs/:slug',
        loadComponent: () => import('./features/programs/program-detail/program-detail.component').then(m => m.ProgramDetailComponent),
        title: 'Program Details | Memu Vunnam Foundation'
      },
      {
        path: 'activities',
        loadComponent: () => import('./features/activities/activities.component').then(m => m.ActivitiesComponent),
        title: 'Activities & Ground Events | Memu Vunnam Foundation'
      },
      {
        path: 'activities/:slug',
        loadComponent: () => import('./features/activities/activity-detail/activity-detail.component').then(m => m.ActivityDetailComponent),
        title: 'Activity Details | Memu Vunnam Foundation'
      },
      {
        path: 'gallery',
        loadComponent: () => import('./features/gallery/gallery.component').then(m => m.GalleryComponent),
        title: 'Photo Gallery | Memu Vunnam Foundation'
      },
      {
        path: 'impact',
        loadComponent: () => import('./features/impact/impact.component').then(m => m.ImpactComponent),
        title: 'Our Verified Impact | Memu Vunnam Foundation'
      },
      {
        path: 'donate',
        loadComponent: () => import('./features/donate/donate.component').then(m => m.DonateComponent),
        title: 'Donate Online | Memu Vunnam Foundation'
      },
      {
        path: 'volunteer',
        loadComponent: () => import('./features/volunteer/volunteer.component').then(m => m.VolunteerComponent),
        title: 'Volunteer Registration | Memu Vunnam Foundation'
      },
      {
        path: 'request-support',
        loadComponent: () => import('./features/request-support/request-support.component').then(m => m.RequestSupportComponent),
        title: 'Request Support / Refer Someone | Memu Vunnam Foundation'
      },
      {
        path: 'stories',
        loadComponent: () => import('./features/stories/stories.component').then(m => m.StoriesComponent),
        title: 'News & Stories | Memu Vunnam Foundation'
      },
      {
        path: 'stories/:slug',
        loadComponent: () => import('./features/stories/story-detail/story-detail.component').then(m => m.StoryDetailComponent),
        title: 'Story Details | Memu Vunnam Foundation'
      },
      {
        path: 'contact',
        loadComponent: () => import('./features/contact/contact.component').then(m => m.ContactComponent),
        title: 'Contact Us | Memu Vunnam Foundation'
      },
      {
        path: 'faq',
        loadComponent: () => import('./features/faq/faq.component').then(m => m.FaqComponent),
        title: 'Frequently Asked Questions | Memu Vunnam Foundation'
      },
      {
        path: 'privacy-policy',
        loadComponent: () => import('./features/legal/privacy-policy.component').then(m => m.PrivacyPolicyComponent),
        title: 'Privacy Policy | Memu Vunnam Foundation'
      },
      {
        path: 'terms',
        loadComponent: () => import('./features/legal/terms.component').then(m => m.TermsComponent),
        title: 'Terms & Conditions | Memu Vunnam Foundation'
      },
      {
        path: '**',
        loadComponent: () => import('./features/not-found/not-found.component').then(m => m.NotFoundComponent),
        title: '404 Page Not Found | Memu Vunnam Foundation'
      }
    ]
  }
];
