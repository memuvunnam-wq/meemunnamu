// =============================================================================
// MEMU VUNNAM FOUNDATION - Core Data Models & TypeScript Interfaces
// Prepared for Node.js REST API & MySQL Database schema compatibility
// =============================================================================

export interface Program {
  id: string;
  slug: string;
  title: string;
  teluguTitle?: string;
  shortDescription: string;
  fullDescription: string;
  category: 'education' | 'health' | 'community' | 'environment' | 'skills' | 'social';
  imageUrl: string;
  icon: string;
  badgeColor: 'primary' | 'green' | 'orange' | 'teal';
  objectives: string[];
  activities: string[];
  beneficiaries: string;
  impactMetrics: string;
  featured: boolean;
  relatedEventSlugs?: string[];
}

export interface ActivityEvent {
  id: string;
  slug: string;
  title: string;
  teluguTitle?: string;
  category: 'education' | 'health' | 'community' | 'environment' | 'skills' | 'general';
  date: string;
  formattedDate: string;
  location: string;
  bannerImage: string;
  galleryImages: string[];
  shortDescription: string;
  fullDescription: string;
  objectives: string[];
  resultsAndImpact: string;
  status: 'upcoming' | 'recent' | 'past';
  organizer: string;
  relatedProgramSlug?: string;
}

export interface GalleryImage {
  id: string;
  title: string;
  category: 'education' | 'health' | 'community' | 'environment' | 'events';
  imageUrl: string;
  caption: string;
  date: string;
  eventReference?: string;
  altText: string;
}

export interface Story {
  id: string;
  slug: string;
  title: string;
  category: 'education' | 'community' | 'healthcare' | 'announcements';
  summary: string;
  content: string[];
  author: string;
  publishedAt: string;
  imageUrl: string;
  readTime: string;
}

export interface ImpactMetric {
  id: string;
  number: string;
  label: string;
  description: string;
  icon: string;
  colorScheme: 'primary' | 'green' | 'orange' | 'teal';
}

export interface TeamMember {
  id: string;
  name: string;
  role: string;
  teluguRole?: string;
  bio: string;
  avatarUrl: string;
}

export interface FaqItem {
  id: string;
  category: 'general' | 'donation' | 'volunteering' | 'programs' | 'support';
  question: string;
  answer: string;
}

export interface VolunteerFormData {
  fullName: string;
  email: string;
  phone: string;
  city: string;
  interests: string[];
  availability: string;
  skillsExperience?: string;
  message?: string;
  privacyConsent: boolean;
}

export interface SupportRequestFormData {
  applicantName: string;
  contactNumber: string;
  email?: string;
  address: string;
  supportType: 'education' | 'medical' | 'community' | 'livelihood' | 'other';
  urgency: 'low' | 'moderate' | 'high' | 'critical';
  details: string;
  estimatedAmountNeeded?: number;
  privacyConsent: boolean;
}

export interface DonationFormData {
  amount: number;
  frequency: 'one_time' | 'monthly';
  donorName: string;
  email: string;
  phone: string;
  panNumber?: string;
  cause: string;
  isAnonymous: boolean;
  paymentMethod: 'upi' | 'bank_transfer' | 'qr';
}

export interface ContactFormData {
  fullName: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
}

export interface ApiResponse<T> {
  success: boolean;
  data: T;
  message?: string;
  timestamp: string;
}

