import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { catchError, throwError } from 'rxjs';

export const apiInterceptor: HttpInterceptorFn = (req, next) => {
  // Add common headers such as Accept and Content-Type for future Node.js REST API
  const cloned = req.clone({
    setHeaders: {
      'Accept': 'application/json',
      'X-Requested-With': 'XMLHttpRequest'
    }
  });

  return next(cloned).pipe(
    catchError((error: HttpErrorResponse) => {
      // Centralized error logging
      console.error('[API Error Interceptor]:', {
        status: error.status,
        statusText: error.statusText,
        url: error.url,
        message: error.message
      });
      return throwError(() => error);
    })
  );
};

