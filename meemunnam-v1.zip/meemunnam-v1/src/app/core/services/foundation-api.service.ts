import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, delay, catchError, map } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  Program,
  ActivityEvent,
  GalleryImage,
  Story,
  ImpactMetric,
  TeamMember,
  FaqItem,
  VolunteerFormData,
  SupportRequestFormData,
  DonationFormData,
  ContactFormData,
  ApiResponse
} from '../models/foundation.models';
import {
  FOUNDATION_INFO,
  MOCK_PROGRAMS,
  MOCK_EVENTS,
  MOCK_GALLERY,
  MOCK_STORIES,
  MOCK_IMPACT_METRICS,
  MOCK_TEAM,
  MOCK_FAQS
} from './foundation-data';

@Injectable({
  providedIn: 'root'
})
export class FoundationApiService {
  private http = inject(HttpClient);
  private apiUrl = environment.apiUrl;
  private useMock = environment.useMockData;

  getFoundationInfo() {
    return FOUNDATION_INFO;
  }

  getPrograms(): Observable<Program[]> {
    if (!this.useMock) {
      return this.http.get<ApiResponse<Program[]>>(`${this.apiUrl}/programs`).pipe(
        map(res => res.data),
        catchError(() => of(MOCK_PROGRAMS))
      );
    }
    return of(MOCK_PROGRAMS).pipe(delay(200));
  }

  getProgramBySlug(slug: string): Observable<Program | undefined> {
    if (!this.useMock) {
      return this.http.get<ApiResponse<Program>>(`${this.apiUrl}/programs/${slug}`).pipe(
        map(res => res.data),
        catchError(() => of(MOCK_PROGRAMS.find(p => p.slug === slug)))
      );
    }
    const found = MOCK_PROGRAMS.find(p => p.slug === slug);
    return of(found).pipe(delay(150));
  }

  getEvents(filter?: { category?: string; status?: string }): Observable<ActivityEvent[]> {
    if (!this.useMock) {
      return this.http.get<ApiResponse<ActivityEvent[]>>(`${this.apiUrl}/events`, { params: filter as any }).pipe(
        map(res => res.data),
        catchError(() => of(this.filterEvents(filter)))
      );
    }
    return of(this.filterEvents(filter)).pipe(delay(200));
  }

  private filterEvents(filter?: { category?: string; status?: string }): ActivityEvent[] {
    let result = [...MOCK_EVENTS];
    if (filter?.category && filter.category !== 'all') {
      result = result.filter(e => e.category === filter.category);
    }
    if (filter?.status && filter.status !== 'all') {
      result = result.filter(e => e.status === filter.status);
    }
    return result;
  }

  getEventBySlug(slug: string): Observable<ActivityEvent | undefined> {
    if (!this.useMock) {
      return this.http.get<ApiResponse<ActivityEvent>>(`${this.apiUrl}/events/${slug}`).pipe(
        map(res => res.data),
        catchError(() => of(MOCK_EVENTS.find(e => e.slug === slug)))
      );
    }
    const found = MOCK_EVENTS.find(e => e.slug === slug);
    return of(found).pipe(delay(150));
  }

  getGalleryImages(category?: string): Observable<GalleryImage[]> {
    if (!this.useMock) {
      return this.http.get<ApiResponse<GalleryImage[]>>(`${this.apiUrl}/gallery`, { params: category ? { category } : {} }).pipe(
        map(res => res.data),
        catchError(() => of(this.filterGallery(category)))
      );
    }
    return of(this.filterGallery(category)).pipe(delay(200));
  }

  private filterGallery(category?: string): GalleryImage[] {
    if (!category || category === 'all') {
      return MOCK_GALLERY;
    }
    return MOCK_GALLERY.filter(img => img.category === category);
  }

  getStories(): Observable<Story[]> {
    if (!this.useMock) {
      return this.http.get<ApiResponse<Story[]>>(`${this.apiUrl}/stories`).pipe(
        map(res => res.data),
        catchError(() => of(MOCK_STORIES))
      );
    }
    return of(MOCK_STORIES).pipe(delay(200));
  }

  getStoryBySlug(slug: string): Observable<Story | undefined> {
    if (!this.useMock) {
      return this.http.get<ApiResponse<Story>>(`${this.apiUrl}/stories/${slug}`).pipe(
        map(res => res.data),
        catchError(() => of(MOCK_STORIES.find(s => s.slug === slug)))
      );
    }
    const found = MOCK_STORIES.find(s => s.slug === slug);
    return of(found).pipe(delay(150));
  }

  getImpactMetrics(): Observable<ImpactMetric[]> {
    return of(MOCK_IMPACT_METRICS).pipe(delay(150));
  }

  getTeamMembers(): Observable<TeamMember[]> {
    return of(MOCK_TEAM).pipe(delay(150));
  }

  getFaqs(category?: string): Observable<FaqItem[]> {
    let result = [...MOCK_FAQS];
    if (category && category !== 'all') {
      result = result.filter(f => f.category === category);
    }
    return of(result).pipe(delay(150));
  }

  submitVolunteer(formData: VolunteerFormData): Observable<ApiResponse<{ id: string }>> {
    if (!this.useMock) {
      return this.http.post<ApiResponse<{ id: string }>>(`${this.apiUrl}/volunteer`, formData);
    }
    const res: ApiResponse<{ id: string }> = {
      success: true,
      data: { id: `VOL-${Date.now().toString().slice(-6)}` },
      message: 'Thank you! Your volunteer application has been received. Our team will contact you soon.',
      timestamp: new Date().toISOString()
    };
    return of(res).pipe(delay(800));
  }

  submitSupportRequest(formData: SupportRequestFormData): Observable<ApiResponse<{ referenceNumber: string }>> {
    if (!this.useMock) {
      return this.http.post<ApiResponse<{ referenceNumber: string }>>(`${this.apiUrl}/support-request`, formData);
    }
    const refNum = `REQ-${Date.now().toString().slice(-6)}`;
    const res: ApiResponse<{ referenceNumber: string }> = {
      success: true,
      data: { referenceNumber: refNum },
      message: `Your support request has been registered under application reference ${refNum}. Our field verification coordinator will reach out within 48-72 hours.`,
      timestamp: new Date().toISOString()
    };
    return of(res).pipe(delay(900));
  }

  submitDonation(formData: DonationFormData): Observable<ApiResponse<{ referenceId: string; receiptNumber: string }>> {
    if (!this.useMock) {
      return this.http.post<ApiResponse<{ referenceId: string; receiptNumber: string }>>(`${this.apiUrl}/donations`, formData);
    }
    const refId = `DON-${Date.now().toString().slice(-6)}`;
    const res: ApiResponse<{ referenceId: string; receiptNumber: string }> = {
      success: true,
      data: {
        referenceId: refId,
        receiptNumber: `MVF-REC-${new Date().getFullYear()}-${Date.now().toString().slice(-4)}`
      },
      message: 'Donation pledge recorded successfully! Please complete your transfer and retain the receipt number.',
      timestamp: new Date().toISOString()
    };
    return of(res).pipe(delay(900));
  }

  submitContact(formData: ContactFormData): Observable<ApiResponse<{ ticketId: string }>> {
    if (!this.useMock) {
      return this.http.post<ApiResponse<{ ticketId: string }>>(`${this.apiUrl}/contact`, formData);
    }
    const res: ApiResponse<{ ticketId: string }> = {
      success: true,
      data: { ticketId: `MSG-${Date.now().toString().slice(-5)}` },
      message: 'Thank you for reaching out to Memu Vunnam Foundation. We will reply to your inquiry shortly.',
      timestamp: new Date().toISOString()
    };
    return of(res).pipe(delay(700));
  }
}

