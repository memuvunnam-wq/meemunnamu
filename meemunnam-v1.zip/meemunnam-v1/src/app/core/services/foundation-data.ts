// =============================================================================
// MEMU VUNNAM FOUNDATION - Configurable Mock Data & Initial State
// All data is cleanly separated from UI components and ready for API binding
// =============================================================================

import {
  Program,
  ActivityEvent,
  GalleryImage,
  Story,
  ImpactMetric,
  TeamMember,
  FaqItem
} from '../models/foundation.models';

export const FOUNDATION_INFO = {
  name: 'Memu Vunnam Foundation',
  teluguName: 'మేము ఉన్నాం ఫౌండేషన్',
  tagline: 'Together We Support. Together We Transform Lives.',
  teluguTagline: 'తోడుగా మేము... బాసటగా సమాజం కోసం',
  description: 'Memu Vunnam Foundation works towards creating meaningful opportunities, supporting communities, and building a better future through compassion and collective action.',
  registrationNumber: 'REG-MVF/XXXX/YYYY [Subject to Official Verification]',
  darpanId: 'AP/XXXX/XXXXXXX [Verification in progress]',
  email: 'contact@meemunnam.org',
  supportEmail: 'help@meemunnam.org',
  phone: '+91 94900 XXXXX',
  altPhone: '+91 98480 XXXXX',
  address: 'Memu Vunnam Foundation Headquarters, Hyderabad & Andhra Pradesh, India [Official premises to be confirmed]',
  workingHours: 'Monday – Saturday: 9:30 AM to 6:30 PM IST',
  socialLinks: {
    facebook: 'https://facebook.com/memuvunnamfoundation',
    instagram: 'https://instagram.com/memuvunnamfoundation',
    twitter: 'https://twitter.com/memuvunnam',
    youtube: 'https://youtube.com/@memuvunnamfoundation',
    linkedin: 'https://linkedin.com/company/memu-vunnam-foundation'
  },
  bankDetails: {
    accountName: 'MEMU VUNNAM FOUNDATION [Official Account]',
    bankName: 'State Bank of India',
    branch: 'Hyderabad Main Branch',
    accountNumber: 'XXXX XXXX XXXX 4092 [Configurable]',
    ifscCode: 'SBIN000XXXX',
    upiId: 'memuvunnam@sbi',
    note: 'Tax exemption certificate 80G/12A under processing. Official verified receipt will be issued upon formal launch.'
  }
};

export const MOCK_PROGRAMS: Program[] = [
  {
    id: 'prog-1',
    slug: 'education-and-student-support',
    title: 'Education and Student Support',
    teluguTitle: 'విద్యా వికాసం & విద్యార్థి ప్రోత్సాహం',
    shortDescription: 'Empowering meritorious and economically underprivileged students with fee assistance, school kits, and academic mentoring.',
    fullDescription: 'Education is the cornerstone of generational transformation. Through our Education Support initiative, we identify talented students from rural and low-income backgrounds who risk dropping out due to economic hardship. We provide complete tuition assistance, stationery kits, bicycles for commute, and personal career mentorship.',
    category: 'education',
    imageUrl: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=900&q=80',
    icon: 'read',
    badgeColor: 'primary',
    objectives: [
      'Eliminate financial dropouts among high-performing rural students',
      'Provide essential learning materials, books, and uniforms at the start of academic terms',
      'Offer college entrance coaching and competitive exam mentorship',
      'Facilitate digital literacy and computer access for government school children'
    ],
    activities: [
      'Merit Scholarship Screening & Award Ceremonies',
      'Annual School Backpack & Study Kit Distribution',
      'Career Guidance Seminars with industry experts and educators',
      'Weekend Remedial Coaching Centers in targeted community clusters'
    ],
    beneficiaries: 'Underprivileged students from Grades 6 through undergraduate college degrees.',
    impactMetrics: '450+ Student Scholarships Enabled • 12 Schools Supported with Learning Aids',
    featured: true,
    relatedEventSlugs: ['merit-student-scholarship-distribution-2025', 'school-kit-distribution-rural-schools']
  },
  {
    id: 'prog-2',
    slug: 'health-and-medical-assistance',
    title: 'Health and Medical Assistance',
    teluguTitle: 'ఆరోగ్య రక్ష & వైద్య సహాయం',
    shortDescription: 'Conducting free health check-up camps, voluntary blood donation drives, and emergency medical relief funds for critical patients.',
    fullDescription: 'Good health is a fundamental right. Memu Vunnam organizes targeted healthcare camps in underserved rural and semi-urban pockets. We coordinate blood donation networks, provide life-saving drug subsidies, and facilitate emergency surgical funds for families who cannot afford catastrophic medical bills.',
    category: 'health',
    imageUrl: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=900&q=80',
    icon: 'medicine-box',
    badgeColor: 'green',
    objectives: [
      'Bring early diagnosis of chronic ailments to remote villages',
      'Bridge blood availability shortages in government blood banks during emergency cases',
      'Support elderly and chronic patients with recurring monthly medications',
      'Deliver seasonal community relief, including hydration centers (Chalivendram) during harsh summers'
    ],
    activities: [
      'Multi-specialty Free Diagnostic and Eye Check-up Camps',
      'Quarterly Voluntary Blood Donation Drives in collaboration with Red Cross',
      'Summer Buttermilk & Drinking Water Stations across busy rural junctions',
      'Emergency Patient Relief Fund allocation for critical procedures'
    ],
    beneficiaries: 'Economically weaker patients, daily wage earners, seniors, and emergency trauma victims.',
    impactMetrics: '1,800+ Diagnostic Screenings Conducted • 520+ Units of Blood Donated',
    featured: true,
    relatedEventSlugs: ['mega-blood-donation-drive-vijayawada', 'summer-chalivendram-buttermilk-relief']
  },
  {
    id: 'prog-3',
    slug: 'community-welfare',
    title: 'Community Welfare & Relief',
    teluguTitle: 'సామాజిక సంక్షేమం & సేవా కార్యక్రమాలు',
    shortDescription: 'Extending a compassionate hand to orphanages, elderly care homes, and vulnerable families through food, clothing, and shelter aid.',
    fullDescription: 'Community welfare is at the very heart of the name Memu Vunnam ("We are with you"). We partner with local elderly shelters, orphanages, and destitute care facilities to ensure dignified living conditions, nutritious food supply, and festival celebrations that bring warmth and togetherness.',
    category: 'community',
    imageUrl: 'https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&w=900&q=80',
    icon: 'heart',
    badgeColor: 'orange',
    objectives: [
      'Supply staple groceries, nutrition, and hygiene essentials to elderly care homes',
      'Celebrate festive occasions with children in orphanages to foster emotional belonging',
      'Provide rapid food and blanket distribution during extreme weather and emergencies',
      'Offer livelihood starter kits for single mothers and differently-abled individuals'
    ],
    activities: [
      'Monthly Annadanam (Nutrition Distribution) in Old Age Shelters',
      'Winter Blanket & Warm Clothing Distribution Drives',
      'Shelter Renovation & Sanitary Infrastructure Upgrades',
      'Disaster Relief response teams during severe floods and rains'
    ],
    beneficiaries: 'Orphans, abandoned seniors, destitute street residents, and families struck by sudden crises.',
    impactMetrics: '3,200+ Nutritious Meals Served • 8 Shelters Supported on a Continuous Basis',
    featured: true,
    relatedEventSlugs: ['annadanam-old-age-home-hyderabad', 'flood-relief-grocery-kits-distribution']
  },
  {
    id: 'prog-4',
    slug: 'environmental-awareness',
    title: 'Environmental Awareness & Plantation',
    teluguTitle: 'పర్యావరణ పరిరక్షణ & హరిత సంకల్పం',
    shortDescription: 'Mass sapling plantation, water conservation awareness, and clean-up drives promoting sustainable community living.',
    fullDescription: 'Our future hinges on protecting our Mother Earth. We mobilize youth and volunteers for massive greening efforts, rainwater harvesting advocacy, plastic reduction campaigns in public spaces, and school nature clubs that instill green consciousness in young minds.',
    category: 'environment',
    imageUrl: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=900&q=80',
    icon: 'environment',
    badgeColor: 'teal',
    objectives: [
      'Plant and nurture native fruit and shade trees in school campuses and public lands',
      'Educate communities on single-use plastic reduction and zero-waste habits',
      'Conduct neighborhood cleanliness and lake boundary restoration drives',
      'Promote rainwater harvesting pit construction in rural educational institutions'
    ],
    activities: [
      'Haritha Vanam Mass Tree Plantation Drives',
      'Plastic-Free Village Campaigns and Cloth Bag Distribution',
      'Pond and Water Body Rejuvenation Volunteering Camps',
      'Eco-friendly Clay Ganesha and Festival Workshops'
    ],
    beneficiaries: 'Local villages, school campuses, municipal parks, and future generations.',
    impactMetrics: '4,500+ Native Saplings Planted • 15 School Green Clubs Established',
    featured: true,
    relatedEventSlugs: ['mass-tree-plantation-green-warangal', 'plastic-free-awareness-cloth-bag-drive']
  },
  {
    id: 'prog-5',
    slug: 'skill-development',
    title: 'Skill Development & Youth Empowerment',
    teluguTitle: 'యువజన నైపుణ్య శిక్షణ & ఉపాధి కల్పన',
    shortDescription: 'Vocational training, resume mentoring, and digital skills workshops that prepare youth and women for self-reliant livelihoods.',
    fullDescription: 'Empowering individuals with marketable skills transforms families out of cycles of poverty. We organize tailor-made skill development workshops—ranging from basic coding and digital tools to tailoring and small enterprise training for women self-help groups.',
    category: 'skills',
    imageUrl: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=900&q=80',
    icon: 'bulb',
    badgeColor: 'primary',
    objectives: [
      'Equip unemployed rural graduates with workplace communication and interview skills',
      'Offer tailoring, craft, and micro-business skills to women in self-help groups',
      'Train students in foundational computer applications and office software',
      'Connect trained candidates to local vocational apprenticeships'
    ],
    activities: [
      '4-Week Intensive Tailoring and Sewing Certification',
      'Basic Computer Skills & Internet Literacy Camps',
      'Career Readiness & Mock Interview Bootcamps',
      'Micro-finance and Entrepreneurship Awareness Sessions'
    ],
    beneficiaries: 'Unemployed youth, college graduates, and homemakers seeking financial independence.',
    impactMetrics: '280+ Youths & Women Trained • 60% Placed in Local Work Opportunities',
    featured: false,
    relatedEventSlugs: []
  },
  {
    id: 'prog-6',
    slug: 'social-responsibility',
    title: 'Social Responsibility & Civic Engagement',
    teluguTitle: 'సామాజిక బాధ్యత & పౌర చైతన్యం',
    shortDescription: 'Inspiring citizens to take active responsibility in community building, road safety, and civic welfare.',
    fullDescription: 'Every positive change begins with citizen involvement. Memu Vunnam organizes civic awareness programs, road safety workshops, constitutional literacy, and emergency disaster volunteering brigades to make communities proactive, vigilant, and resilient.',
    category: 'social',
    imageUrl: 'https://images.unsplash.com/photo-1559027615-cd4628902d4a?auto=format&fit=crop&w=900&q=80',
    icon: 'team',
    badgeColor: 'orange',
    objectives: [
      'Foster a culture of volunteerism among college students and working professionals',
      'Promote helmet wearing, defensive driving, and pedestrian safety',
      'Spread awareness of welfare schemes offered by state and central governments',
      'Train youth volunteers in first-aid response and disaster mitigation'
    ],
    activities: [
      'Youth Leadership and Volunteering Orientation',
      'Traffic Safety and Helmet Awareness Street Rallies',
      'Right to Information (RTI) and Civic Entitlement Workshops',
      'Emergency First-Aid and CPR Training Camps'
    ],
    beneficiaries: 'General public, college students, drivers, and local community residents.',
    impactMetrics: '20+ Civic Workshops • 600+ Active Volunteers Onboarded',
    featured: false,
    relatedEventSlugs: []
  }
];

export const MOCK_EVENTS: ActivityEvent[] = [
  {
    id: 'evt-1',
    slug: 'merit-student-scholarship-distribution-2025',
    title: 'Merit Student Scholarship & Laptop Aid 2025',
    teluguTitle: 'ప్రతిభావంత విద్యార్థులకు ఉపకార వేతనాల ప్రదానం',
    category: 'education',
    date: '2025-07-15',
    formattedDate: 'July 15, 2025',
    location: 'Community Town Hall, Guntur, AP',
    bannerImage: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?auto=format&fit=crop&w=800&q=80'
    ],
    shortDescription: 'Awarded annual education fee subsidies and laptops to 45 meritorious students from economically challenged households.',
    fullDescription: 'The Memu Vunnam Annual Scholarship Distribution brought together teachers, parents, and community leaders. Over 45 high school and diploma students with exceptional academic standing received full annual fees aid, textbooks, and certificate recognitions. Two engineering aspirants received refurbished laptops to support their software curriculum.',
    objectives: [
      'Relieve parents from immediate loan stress for educational terms',
      'Reward dedication and diligence among rural government school achievers',
      'Introduce mentorship pairings with working corporate volunteers'
    ],
    resultsAndImpact: '45 Students supported for the academic year 2025-26 with 100% attendance retention.',
    status: 'recent',
    organizer: 'Memu Vunnam Education Wing',
    relatedProgramSlug: 'education-and-student-support'
  },
  {
    id: 'evt-2',
    slug: 'mega-blood-donation-drive-vijayawada',
    title: 'Mega Blood Donation Drive & Health Screening',
    teluguTitle: 'మహా రక్తదాన శిబిరం & ఉచిత వైద్య పరీక్షలు',
    category: 'health',
    date: '2025-08-20',
    formattedDate: 'August 20, 2025',
    location: 'Siddhartha College Auditorium, Vijayawada',
    bannerImage: 'https://images.unsplash.com/photo-1615461066841-6116e61058f4?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1615461066841-6116e61058f4?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1579684385127-1ef15d508118?auto=format&fit=crop&w=800&q=80'
    ],
    shortDescription: 'Collected 140+ blood units in collaboration with the Government General Hospital Blood Bank to address critical surgical shortages.',
    fullDescription: 'Organized on World Humanitarian Day, this drive witnessed enthusiastic participation from youth, college students, and foundation volunteers. In addition to blood collection, doctors offered free general health check-ups, BP & sugar tests, and hemoglobin assessments for female participants.',
    objectives: [
      'Replenish regional blood bank reserves for thalassemia and trauma care',
      'Dispel myths surrounding voluntary blood donation among young adults',
      'Provide basic diagnostic tests free of charge'
    ],
    resultsAndImpact: '142 units collected safely; 210 citizens screened for preventive health parameters.',
    status: 'recent',
    organizer: 'Memu Vunnam Healthcare Cell',
    relatedProgramSlug: 'health-and-medical-assistance'
  },
  {
    id: 'evt-3',
    slug: 'summer-chalivendram-buttermilk-relief',
    title: 'Summer Hydration Chalivendram & Buttermilk Distribution',
    teluguTitle: 'వేసవి చలివేంద్రం & మజ్జిగ పంపిణీ',
    category: 'community',
    date: '2025-05-10',
    formattedDate: 'May 10 – June 05, 2025',
    location: 'Bus Station & Market Junctions, Khammam & Warangal',
    bannerImage: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80'
    ],
    shortDescription: 'Daily cool buttermilk and hygienic drinking water distribution to daily laborers, auto drivers, and travelers during peak summer temperatures.',
    fullDescription: 'To mitigate severe heat wave conditions where temperatures crossed 44°C, Memu Vunnam installed 4 community Chalivendram centers in high-footfall intersections. Volunteers prepared fresh buttermilk and cool earthen-pot drinking water daily for 25 days, preventing sunstrokes and severe dehydration.',
    objectives: [
      'Offer immediate relief to outdoor laborers, traffic wardens, and commuters',
      'Ensure hygienic water filtration and eco-friendly paper/earthen serving cups',
      'Foster community spirit and volunteer care in sweltering months'
    ],
    resultsAndImpact: 'Over 12,000 travelers and workers quenched their thirst during the heat peak.',
    status: 'past',
    organizer: 'Memu Vunnam Youth Brigade',
    relatedProgramSlug: 'community-welfare'
  },
  {
    id: 'evt-4',
    slug: 'mass-tree-plantation-green-warangal',
    title: 'Haritha Sankalpam – Mass Plantation Drive',
    teluguTitle: 'హరిత సంకల్పం – మొక్కలు నాటే మహోద్యమం',
    category: 'environment',
    date: '2025-09-08',
    formattedDate: 'September 08, 2025',
    location: 'Zilla Parishad High School, Kazipet',
    bannerImage: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1466692476868-aef1dfb1e735?auto=format&fit=crop&w=800&q=80'
    ],
    shortDescription: 'Planted 500+ shade-giving and neem saplings across three rural school campuses with student adoption pledges.',
    fullDescription: 'Students and volunteers worked shoulder to shoulder to plant 500 saplings. Each student took an adoption oath to water and nurture one plant through their academic year, pairing environmental conservation with personal responsibility.',
    objectives: [
      'Create green canopies in barren school playgrounds',
      'Instill eco-awareness and nature stewardship in children',
      'Promote tree survival rate with dedicated tree guards and drip bottles'
    ],
    resultsAndImpact: '500+ saplings planted with 88% monitored survival rate to date.',
    status: 'recent',
    organizer: 'Memu Vunnam Eco Team',
    relatedProgramSlug: 'environmental-awareness'
  },
  {
    id: 'evt-5',
    slug: 'upcoming-winter-warmth-blanket-drive-2025',
    title: 'Winter Warmth & Shelter Aid Drive 2025',
    teluguTitle: 'చలికాలపు దుప్పట్ల పంపిణీ శిబిరం',
    category: 'community',
    date: '2025-11-25',
    formattedDate: 'November 25, 2025',
    location: 'Old Age Home & Orphanage Clusters, Hyderabad',
    bannerImage: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=900&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&w=800&q=80'
    ],
    shortDescription: 'Upcoming distribution of high-grade wool blankets, thermal wear, and nutrition kits for abandoned seniors and night shelter inmates.',
    fullDescription: 'As winter approaches, nights become punishing for the destitute and elder homes without heating. Memu Vunnam is mobilizing community donations to purchase 1,000 thick blankets, thermal vests, and nutritional supplements for distribution across 12 verified shelters.',
    objectives: [
      'Protect vulnerable seniors and destitute citizens from cold illness and pneumonia',
      'Deliver emergency rations and immunity booster medicines',
      'Spread warmth, empathy, and social solidarity'
    ],
    resultsAndImpact: 'Target: 1,000 beneficiaries across Hyderabad, Secunderabad, and rural outskirts.',
    status: 'upcoming',
    organizer: 'Memu Vunnam Volunteer Team',
    relatedProgramSlug: 'community-welfare'
  }
];

export const MOCK_GALLERY: GalleryImage[] = [
  {
    id: 'gal-1',
    title: 'Merit Scholarship Awardees with Dignitaries',
    category: 'education',
    imageUrl: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=800&q=80',
    caption: 'Students receiving their academic scholarship certificates at the annual ceremony.',
    date: 'July 2025',
    eventReference: 'Merit Student Scholarship & Laptop Aid 2025',
    altText: 'Students happily holding scholarship certificates'
  },
  {
    id: 'gal-2',
    title: 'School Backpack & Learning Kits Handover',
    category: 'education',
    imageUrl: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=800&q=80',
    caption: 'Government primary school children receiving new backpacks, notebooks, and geometry boxes.',
    date: 'June 2025',
    eventReference: 'School Kit Distribution Rural Schools',
    altText: 'Children in school uniforms with new backpacks'
  },
  {
    id: 'gal-3',
    title: 'Voluntary Blood Donation Camp',
    category: 'health',
    imageUrl: 'https://images.unsplash.com/photo-1615461066841-6116e61058f4?auto=format&fit=crop&w=800&q=80',
    caption: 'Youth volunteer donating blood under medical supervision during the Vijayawada camp.',
    date: 'August 2025',
    eventReference: 'Mega Blood Donation Drive & Health Screening',
    altText: 'Blood donation camp in progress'
  },
  {
    id: 'gal-4',
    title: 'Elderly Health Diagnostic Screening',
    category: 'health',
    imageUrl: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=800&q=80',
    caption: 'Senior citizens receiving free blood sugar and cardiovascular diagnostics from volunteer doctors.',
    date: 'August 2025',
    altText: 'Doctor examining an elderly patient'
  },
  {
    id: 'gal-5',
    title: 'Summer Chalivendram Refreshment Center',
    category: 'community',
    imageUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80',
    caption: 'Volunteers serving fresh buttermilk to travelers and daily wage workers.',
    date: 'May 2025',
    eventReference: 'Summer Hydration Chalivendram',
    altText: 'Refreshing buttermilk distribution stall'
  },
  {
    id: 'gal-6',
    title: 'Annadanam & Meal Distribution at Old Age Home',
    category: 'community',
    imageUrl: 'https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&w=800&q=80',
    caption: 'Serving freshly cooked nutritious lunch to inmates of Anandha Nilayam elderly home.',
    date: 'April 2025',
    altText: 'Volunteers serving hot food to elders'
  },
  {
    id: 'gal-7',
    title: 'Haritha Sankalpam Tree Plantation in Progress',
    category: 'environment',
    imageUrl: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=800&q=80',
    caption: 'Volunteers and school students digging soil and planting neem saplings.',
    date: 'September 2025',
    eventReference: 'Haritha Sankalpam Mass Plantation Drive',
    altText: 'Students planting sapling in school ground'
  },
  {
    id: 'gal-8',
    title: 'Women Tailoring Certification Workshop',
    category: 'events',
    imageUrl: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=800&q=80',
    caption: 'Participants showcasing self-stitched garments after completing their 4-week course.',
    date: 'June 2025',
    altText: 'Women with certificates and tailoring equipment'
  },
  {
    id: 'gal-9',
    title: 'Youth Volunteer Brigade Orientation',
    category: 'events',
    imageUrl: 'https://images.unsplash.com/photo-1559027615-cd4628902d4a?auto=format&fit=crop&w=800&q=80',
    caption: 'Annual meeting of foundation volunteers planning civic relief activities for the upcoming term.',
    date: 'January 2025',
    altText: 'Group of passionate young volunteers smiling'
  }
];

export const MOCK_STORIES: Story[] = [
  {
    id: 'story-1',
    slug: 'from-village-school-to-polytechnic-ramesh-journey',
    title: 'From Financial Uncertainty to an Engineering Seat: Ramesh’s Journey',
    category: 'education',
    summary: 'How merit scholarship and timely mentorship helped a farmer’s son secure admission into a top government polytechnic.',
    content: [
      'Ramesh, hailing from a small village near Tenali, stood first in his Class 10 board exams with a 9.8 GPA. However, his family faced severe debt due to crop failure, and his dream of continuing his studies in engineering seemed practically out of reach.',
      'Through a school teacher recommendation, Ramesh’s case was referred to the Memu Vunnam Foundation. Following our verification visit, the foundation granted full tuition support, hostel fees, and a study tablet.',
      'Today, Ramesh is in his second year of Diploma in Computer Engineering, maintaining a consistent top percentile. "When my parents lost hope, Memu Vunnam stood with us," Ramesh shares. "My dream is to become a software engineer and support other students like me."'
    ],
    author: 'Foundation Education Team',
    publishedAt: 'August 12, 2025',
    imageUrl: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=900&q=80',
    readTime: '3 min read'
  },
  {
    id: 'story-2',
    slug: 'chalivendram-relief-saving-lives-during-heatwave',
    title: 'Beat the Heat: How 25 Days of Chalivendram Brought Relief to Thousands',
    category: 'community',
    summary: 'A look into how community water centers provided vital hydration to daily wage workers during scorching summer months.',
    content: [
      'During May 2025, temperatures soared beyond 44 degrees across Andhra and Telangana. For daily wage laborers, rickshaw drivers, and traffic personnel who cannot afford to take a day off, dehydration and sunstroke pose severe hazards.',
      'Memu Vunnam volunteers set up four dedicated Chalivendram points with continuous fresh buttermilk and chilled earthen pots. Local grocers and community donors contributed curd, lemons, and ginger.',
      'Over 25 grueling days, more than 12,000 cups were distributed daily. A simple gesture of cool buttermilk provided a life-saving pause in the blistering heat.'
    ],
    author: 'Community Outreach Cell',
    publishedAt: 'June 18, 2025',
    imageUrl: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=900&q=80',
    readTime: '4 min read'
  },
  {
    id: 'story-3',
    slug: 'haritha-vanam-students-pledge-for-green-future',
    title: 'Haritha Vanam: Why Every Sapling Has a Student Guardian',
    category: 'community',
    summary: 'The green initiative that pairs saplings with school students, achieving an unprecedented 88% survival rate.',
    content: [
      'Too often, tree plantation drives end the moment cameras stop clicking. Seedlings wither away without water or protection.',
      'Memu Vunnam adopted a different, child-centric philosophy. Each child in the participating school adopted a specific sapling, naming it and taking an oath to water it every morning before classes start.',
      'The results have been astonishing. Six months later, over 88% of the planted saplings are flourishing into healthy young trees, teaching students accountability and environmental empathy.'
    ],
    author: 'Eco Awareness Wing',
    publishedAt: 'September 24, 2025',
    imageUrl: 'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?auto=format&fit=crop&w=900&q=80',
    readTime: '3 min read'
  }
];

export const MOCK_IMPACT_METRICS: ImpactMetric[] = [
  {
    id: 'impact-1',
    number: '450+',
    label: 'Students Supported',
    description: 'Received annual scholarships, school backpacks, and educational mentoring.',
    icon: 'book',
    colorScheme: 'primary'
  },
  {
    id: 'impact-2',
    number: '1,800+',
    label: 'Medical Screenings',
    description: 'Free diagnostic checks, blood pressure screenings, and eye health camps.',
    icon: 'heart',
    colorScheme: 'green'
  },
  {
    id: 'impact-3',
    number: '4,500+',
    label: 'Saplings Planted',
    description: 'Native shade and fruit trees planted in schools and community centers.',
    icon: 'environment',
    colorScheme: 'teal'
  },
  {
    id: 'impact-4',
    number: '12,000+',
    label: 'Summer Hydrations',
    description: 'Refreshing buttermilk and chilled drinking water cups served in heatwaves.',
    icon: 'coffee',
    colorScheme: 'orange'
  }
];

export const MOCK_TEAM: TeamMember[] = [
  {
    id: 'tm-1',
    name: 'Sri V. Ramachandra Rao',
    role: 'Founder & Managing Trustee',
    teluguRole: 'వ్యవస్థాపకుడు & మేనేజింగ్ ట్రస్టీ',
    bio: 'Dedicated social activist with over 15 years of grassroots community service, dedicated to youth upliftment and public health.',
    avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 'tm-2',
    name: 'Smt. K. Sunitha Devi',
    role: 'Trustee – Education Initiatives',
    teluguRole: 'ట్రస్టీ – విద్యా వికాస విభాగం',
    bio: 'Senior educator and mentor passionately guiding underprivileged student scholarship programs and rural school library developments.',
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 'tm-3',
    name: 'Dr. P. Nageswara Rao',
    role: 'Medical Advisor & Health Lead',
    teluguRole: 'వైద్య సలహాదారు & ఆరోగ్య విభాగ అధిపతి',
    bio: 'Physician and voluntary healthcare champion overseeing free medical camps, blood donation coordination, and patient aid.',
    avatarUrl: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 'tm-4',
    name: 'Sri M. Suresh Kumar',
    role: 'Coordinator – Volunteer Operations',
    teluguRole: 'సమన్వయకర్త – స్వచ్ఛంద సేవకులు',
    bio: 'Youth leader mobilizing college student networks, emergency summer relief camps, and tree plantation drives across the state.',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80'
  }
];

export const MOCK_FAQS: FaqItem[] = [
  {
    id: 'faq-1',
    category: 'general',
    question: 'What is the vision and mission of Memu Vunnam Foundation?',
    answer: 'Memu Vunnam Foundation (మేము ఉన్నాం ఫౌండేషన్) is dedicated to standing with economically disadvantaged communities. Our mission focuses on student education assistance, free healthcare access, community relief for the elderly and vulnerable, and environmental conservation.'
  },
  {
    id: 'faq-2',
    category: 'donation',
    question: 'How are donation funds utilized by the foundation?',
    answer: '100% of public donations directly fund ground programs: student scholarships, school study kits, free diagnostic camps, food distribution for old age homes, and summer hydration camps. We maintain transparent audit reports, and all administrative overheads are supported by founder contributions.'
  },
  {
    id: 'faq-3',
    category: 'donation',
    question: 'Can I donate via UPI or Direct Bank Transfer?',
    answer: 'Yes! You can donate securely via official UPI (memuvunnam@sbi) or NEFT/RTGS bank transfer to our official State Bank of India account. Please share your transaction reference and contact details on our Donate page so we can email your formal acknowledgment receipt.'
  },
  {
    id: 'faq-4',
    category: 'volunteering',
    question: 'Who can become a volunteer with Memu Vunnam?',
    answer: 'Anyone with compassion and willingness to serve! We welcome students, corporate professionals, doctors, teachers, and retired citizens. You can participate in weekend medical camps, study kit distributions, or online social awareness campaigns.'
  },
  {
    id: 'faq-5',
    category: 'support',
    question: 'How can an individual or student apply for assistance?',
    answer: 'Visit our "Request Support" page and fill out the applicant details, type of support required (education fee, medical aid, or emergency relief), and description. Our verification team will review the application, make a home or institution visit, and respond promptly.'
  },
  {
    id: 'faq-6',
    category: 'programs',
    question: 'Where are Memu Vunnam activities currently active?',
    answer: 'Our ground activities are currently centered across various districts in Telangana and Andhra Pradesh, including Hyderabad, Vijayawada, Guntur, Warangal, and Khammam, with plans to expand reach as volunteer circles grow.'
  }
];

