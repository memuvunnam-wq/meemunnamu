import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from '../header/header.component';
import { FooterComponent } from '../footer/footer.component';

@Component({
  selector: 'app-main-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet, HeaderComponent, FooterComponent],
  template: `
    <div class="mvf-app-layout">
      <app-header></app-header>
      <main id="main-content" class="mvf-main-content">
        <router-outlet></router-outlet>
      </main>
      <app-footer></app-footer>
    </div>
  `,
  styles: [`
    .mvf-app-layout {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }
    .mvf-main-content {
      flex: 1 0 auto;
    }
  `]
})
export class MainLayoutComponent {}

