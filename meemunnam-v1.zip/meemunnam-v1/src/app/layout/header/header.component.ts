import { Component, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { NzDrawerModule } from 'ng-zorro-antd/drawer';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { FOUNDATION_INFO } from '../../core/services/foundation-data';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    RouterLinkActive,
    NzDrawerModule,
    NzIconModule,
    NzButtonModule
  ],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  foundation = FOUNDATION_INFO;
  isMobileDrawerVisible = false;
  isScrolled = false;

  navLinks = [
    { label: 'Home', path: '/', exact: true },
    { label: 'About Us', path: '/about', exact: false },
    { label: 'Our Programs', path: '/programs', exact: false },
    { label: 'Activities & Events', path: '/activities', exact: false },
    { label: 'Gallery', path: '/gallery', exact: false },
    { label: 'Our Impact', path: '/impact', exact: false },
    { label: 'Stories', path: '/stories', exact: false },
    { label: 'FAQ', path: '/faq', exact: false },
    { label: 'Contact', path: '/contact', exact: false }
  ];

  @HostListener('window:scroll')
  onWindowScroll() {
    this.isScrolled = window.scrollY > 40;
  }

  openMobileDrawer(): void {
    this.isMobileDrawerVisible = true;
  }

  closeMobileDrawer(): void {
    this.isMobileDrawerVisible = false;
  }
}

