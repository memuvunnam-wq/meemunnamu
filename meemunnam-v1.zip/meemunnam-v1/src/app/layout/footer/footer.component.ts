import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { FOUNDATION_INFO } from '../../core/services/foundation-data';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [CommonModule, RouterLink, NzIconModule],
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent {
  foundation = FOUNDATION_INFO;
  currentYear = new Date().getFullYear();

  focusAreas = [
    { label: 'Education & Student Support', slug: 'education-and-student-support' },
    { label: 'Health & Medical Assistance', slug: 'health-and-medical-assistance' },
    { label: 'Community Welfare & Relief', slug: 'community-welfare' },
    { label: 'Environmental Awareness', slug: 'environmental-awareness' },
    { label: 'Skill Development', slug: 'skill-development' },
    { label: 'Social Responsibility', slug: 'social-responsibility' }
  ];

  quickLinks = [
    { label: 'Home', path: '/' },
    { label: 'About Our Foundation', path: '/about' },
    { label: 'Activities & Events', path: '/activities' },
    { label: 'Photo Gallery', path: '/gallery' },
    { label: 'Our Verified Impact', path: '/impact' },
    { label: 'Volunteer With Us', path: '/volunteer' },
    { label: 'Request Support / Refer', path: '/request-support' },
    { label: 'Frequently Asked Questions', path: '/faq' },
    { label: 'Contact Us', path: '/contact' }
  ];
}

