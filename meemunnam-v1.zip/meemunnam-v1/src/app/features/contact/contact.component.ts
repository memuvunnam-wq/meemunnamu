import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { PageHeaderComponent } from '../../shared/components/page-header/page-header.component';
import { FoundationApiService } from '../../core/services/foundation-api.service';
import { FOUNDATION_INFO } from '../../core/services/foundation-data';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NzIconModule,
    PageHeaderComponent
  ],
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit {
  private fb = inject(FormBuilder);
  private api = inject(FoundationApiService);

  foundation = FOUNDATION_INFO;
  contactForm!: FormGroup;

  isSubmitting = false;
  submissionSuccess = false;
  assignedTicketId?: string;

  breadcrumbs = [{ label: 'Contact Us' }];

  ngOnInit(): void {
    this.contactForm = this.fb.group({
      fullName: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [Validators.required, Validators.pattern(/^[6-9]\d{9}$/)]],
      subject: ['', [Validators.required, Validators.minLength(4)]],
      message: ['', [Validators.required, Validators.minLength(15)]]
    });
  }

  onSubmit(): void {
    if (this.contactForm.invalid) {
      Object.values(this.contactForm.controls).forEach(c => c.markAsTouched());
      return;
    }

    this.isSubmitting = true;
    this.api.submitContact(this.contactForm.value).subscribe({
      next: res => {
        this.isSubmitting = false;
        this.submissionSuccess = true;
        this.assignedTicketId = res.data.ticketId;
      },
      error: () => {
        this.isSubmitting = false;
      }
    });
  }

  resetForm(): void {
    this.submissionSuccess = false;
    this.assignedTicketId = undefined;
    this.contactForm.reset();
  }
}
