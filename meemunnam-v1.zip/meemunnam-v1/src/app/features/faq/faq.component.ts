import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzCollapseModule } from 'ng-zorro-antd/collapse';
import { PageHeaderComponent } from '../../shared/components/page-header/page-header.component';
import { CtaBannerComponent } from '../../shared/components/cta-banner/cta-banner.component';
import { FoundationApiService } from '../../core/services/foundation-api.service';
import { FaqItem } from '../../core/models/foundation.models';

@Component({
  selector: 'app-faq',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    NzIconModule,
    NzCollapseModule,
    PageHeaderComponent,
    CtaBannerComponent
  ],
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.scss']
})
export class FaqComponent implements OnInit {
  private api = inject(FoundationApiService);

  allFaqs: FaqItem[] = [];
  filteredFaqs: FaqItem[] = [];
  activeCategory = 'all';

  categories = [
    { id: 'all', label: 'All Questions' },
    { id: 'general', label: 'About Foundation' },
    { id: 'donation', label: 'Donations & Receipts' },
    { id: 'volunteering', label: 'Volunteering' },
    { id: 'programs', label: 'Programs & Operations' },
    { id: 'support', label: 'Requesting Support' }
  ];

  breadcrumbs = [{ label: 'Frequently Asked Questions' }];

  ngOnInit(): void {
    this.api.getFaqs().subscribe(faqs => {
      this.allFaqs = faqs;
      this.filterFaqs(this.activeCategory);
    });
  }

  filterFaqs(catId: string): void {
    this.activeCategory = catId;
    if (catId === 'all') {
      this.filteredFaqs = [...this.allFaqs];
    } else {
      this.filteredFaqs = this.allFaqs.filter(f => f.category === catId);
    }
  }
}

