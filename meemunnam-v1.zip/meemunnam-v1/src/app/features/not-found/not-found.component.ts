import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';

@Component({
  selector: 'app-not-found',
  standalone: true,
  imports: [CommonModule, RouterLink, NzIconModule],
  templateUrl: './not-found.component.html',
  styleUrls: ['./not-found.component.scss']
})
export class NotFoundComponent {
  helpfulLinks = [
    { label: 'Home Page', path: '/' },
    { label: 'Our Programs', path: '/programs' },
    { label: 'Activities & Events', path: '/activities' },
    { label: 'Donate Online', path: '/donate' },
    { label: 'Volunteer With Us', path: '/volunteer' },
    { label: 'Contact Us', path: '/contact' }
  ];
}

