import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { PageHeaderComponent } from '../../shared/components/page-header/page-header.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { CtaBannerComponent } from '../../shared/components/cta-banner/cta-banner.component';
import { FoundationApiService } from '../../core/services/foundation-api.service';
import { GalleryImage } from '../../core/models/foundation.models';

@Component({
  selector: 'app-gallery',
  standalone: true,
  imports: [
    CommonModule,
    NzIconModule,
    NzModalModule,
    PageHeaderComponent,
    EmptyStateComponent,
    CtaBannerComponent
  ],
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.scss']
})
export class GalleryComponent implements OnInit {
  private api = inject(FoundationApiService);

  allImages: GalleryImage[] = [];
  filteredImages: GalleryImage[] = [];
  activeCategory: string = 'all';

  // Lightbox Modal state
  isModalVisible = false;
  activeImage?: GalleryImage;

  categories = [
    { id: 'all', label: 'All Photos' },
    { id: 'education', label: 'Education & Students' },
    { id: 'health', label: 'Medical & Blood Camps' },
    { id: 'community', label: 'Community & Relief' },
    { id: 'environment', label: 'Tree Plantation' },
    { id: 'events', label: 'Volunteer Moments' }
  ];

  breadcrumbs = [{ label: 'Photo Gallery' }];

  ngOnInit(): void {
    this.api.getGalleryImages().subscribe(imgs => {
      this.allImages = imgs;
      this.filterImages(this.activeCategory);
    });
  }

  filterImages(catId: string): void {
    this.activeCategory = catId;
    if (catId === 'all') {
      this.filteredImages = [...this.allImages];
    } else {
      this.filteredImages = this.allImages.filter(img => img.category === catId);
    }
  }

  openLightbox(image: GalleryImage): void {
    this.activeImage = image;
    this.isModalVisible = true;
  }

  closeLightbox(): void {
    this.isModalVisible = false;
    this.activeImage = undefined;
  }
}

