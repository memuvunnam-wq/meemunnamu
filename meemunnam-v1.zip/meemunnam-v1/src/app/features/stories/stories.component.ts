import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { PageHeaderComponent } from '../../shared/components/page-header/page-header.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { CtaBannerComponent } from '../../shared/components/cta-banner/cta-banner.component';
import { FoundationApiService } from '../../core/services/foundation-api.service';
import { Story } from '../../core/models/foundation.models';

@Component({
  selector: 'app-stories',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    RouterLink,
    NzIconModule,
    PageHeaderComponent,
    EmptyStateComponent,
    CtaBannerComponent
  ],
  templateUrl: './stories.component.html',
  styleUrls: ['./stories.component.scss']
})
export class StoriesComponent implements OnInit {
  private api = inject(FoundationApiService);

  allStories: Story[] = [];
  filteredStories: Story[] = [];

  searchQuery = '';
  activeCategory = 'all';

  categories = [
    { id: 'all', label: 'All Stories' },
    { id: 'education', label: 'Education & Youth' },
    { id: 'community', label: 'Community Relief' },
    { id: 'healthcare', label: 'Healthcare & Blood' }
  ];

  breadcrumbs = [{ label: 'News & Stories' }];

  ngOnInit(): void {
    this.api.getStories().subscribe(stories => {
      this.allStories = stories;
      this.applyFilters();
    });
  }

  setCategory(catId: string): void {
    this.activeCategory = catId;
    this.applyFilters();
  }

  onSearchChange(): void {
    this.applyFilters();
  }

  applyFilters(): void {
    let result = [...this.allStories];

    if (this.activeCategory !== 'all') {
      result = result.filter(s => s.category === this.activeCategory);
    }

    if (this.searchQuery.trim()) {
      const q = this.searchQuery.toLowerCase().trim();
      result = result.filter(s =>
        s.title.toLowerCase().includes(q) ||
        s.summary.toLowerCase().includes(q)
      );
    }

    this.filteredStories = result;
  }

  resetFilters(): void {
    this.searchQuery = '';
    this.activeCategory = 'all';
    this.applyFilters();
  }
}

