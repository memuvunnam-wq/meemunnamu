import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { PageHeaderComponent } from '../../../shared/components/page-header/page-header.component';
import { CtaBannerComponent } from '../../../shared/components/cta-banner/cta-banner.component';
import { FoundationApiService } from '../../../core/services/foundation-api.service';
import { Story } from '../../../core/models/foundation.models';

@Component({
  selector: 'app-story-detail',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    NzIconModule,
    PageHeaderComponent,
    CtaBannerComponent
  ],
  templateUrl: './story-detail.component.html',
  styleUrls: ['./story-detail.component.scss']
})
export class StoryDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private api = inject(FoundationApiService);

  story?: Story;
  isLoading = true;
  breadcrumbs: { label: string; url?: string }[] = [];

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const slug = params.get('slug');
      if (slug) {
        this.loadStory(slug);
      }
    });
  }

  private loadStory(slug: string): void {
    this.isLoading = true;
    this.api.getStoryBySlug(slug).subscribe(s => {
      this.story = s;
      this.isLoading = false;
      if (s) {
        this.breadcrumbs = [
          { label: 'News & Stories', url: '/stories' },
          { label: s.title }
        ];
      }
    });
  }
}

