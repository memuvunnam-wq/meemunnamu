import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzInputModule } from 'ng-zorro-antd/input';
import { PageHeaderComponent } from '../../shared/components/page-header/page-header.component';
import { EventCardComponent } from '../../shared/components/event-card/event-card.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { CtaBannerComponent } from '../../shared/components/cta-banner/cta-banner.component';
import { FoundationApiService } from '../../core/services/foundation-api.service';
import { ActivityEvent } from '../../core/models/foundation.models';

@Component({
  selector: 'app-activities',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    NzIconModule,
    NzInputModule,
    PageHeaderComponent,
    EventCardComponent,
    EmptyStateComponent,
    CtaBannerComponent
  ],
  templateUrl: './activities.component.html',
  styleUrls: ['./activities.component.scss']
})
export class ActivitiesComponent implements OnInit {
  private api = inject(FoundationApiService);

  allEvents: ActivityEvent[] = [];
  filteredEvents: ActivityEvent[] = [];

  searchQuery = '';
  activeStatus = 'all';
  activeCategory = 'all';

  statusFilters = [
    { id: 'all', label: 'All Activities' },
    { id: 'upcoming', label: 'Upcoming Events' },
    { id: 'recent', label: 'Recent Drives' },
    { id: 'past', label: 'Past Archives' }
  ];

  categoryFilters = [
    { id: 'all', label: 'All Fields' },
    { id: 'education', label: 'Education' },
    { id: 'health', label: 'Health' },
    { id: 'community', label: 'Community' },
    { id: 'environment', label: 'Environment' }
  ];

  breadcrumbs = [{ label: 'Activities & Events' }];

  ngOnInit(): void {
    this.api.getEvents().subscribe(events => {
      this.allEvents = events;
      this.applyFilters();
    });
  }

  setStatus(statusId: string): void {
    this.activeStatus = statusId;
    this.applyFilters();
  }

  setCategory(catId: string): void {
    this.activeCategory = catId;
    this.applyFilters();
  }

  onSearchChange(): void {
    this.applyFilters();
  }

  applyFilters(): void {
    let result = [...this.allEvents];

    if (this.activeStatus !== 'all') {
      result = result.filter(e => e.status === this.activeStatus);
    }

    if (this.activeCategory !== 'all') {
      result = result.filter(e => e.category === this.activeCategory);
    }

    if (this.searchQuery.trim()) {
      const q = this.searchQuery.toLowerCase().trim();
      result = result.filter(e =>
        e.title.toLowerCase().includes(q) ||
        e.location.toLowerCase().includes(q) ||
        e.shortDescription.toLowerCase().includes(q)
      );
    }

    this.filteredEvents = result;
  }

  resetFilters(): void {
    this.searchQuery = '';
    this.activeStatus = 'all';
    this.activeCategory = 'all';
    this.applyFilters();
  }
}
