import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { PageHeaderComponent } from '../../../shared/components/page-header/page-header.component';
import { CtaBannerComponent } from '../../../shared/components/cta-banner/cta-banner.component';
import { FoundationApiService } from '../../../core/services/foundation-api.service';
import { ActivityEvent } from '../../../core/models/foundation.models';

@Component({
  selector: 'app-activity-detail',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    NzIconModule,
    PageHeaderComponent,
    CtaBannerComponent
  ],
  templateUrl: './activity-detail.component.html',
  styleUrls: ['./activity-detail.component.scss']
})
export class ActivityDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private api = inject(FoundationApiService);

  event?: ActivityEvent;
  relatedEvents: ActivityEvent[] = [];
  isLoading = true;
  breadcrumbs: { label: string; url?: string }[] = [];

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const slug = params.get('slug');
      if (slug) {
        this.loadEvent(slug);
      }
    });
  }

  private loadEvent(slug: string): void {
    this.isLoading = true;
    this.api.getEventBySlug(slug).subscribe(ev => {
      this.event = ev;
      this.isLoading = false;
      if (ev) {
        this.breadcrumbs = [
          { label: 'Activities & Events', url: '/activities' },
          { label: ev.title }
        ];

        this.api.getEvents().subscribe(all => {
          this.relatedEvents = all.filter(e => e.slug !== ev.slug && e.category === ev.category).slice(0, 2);
        });
      }
    });
  }
}

