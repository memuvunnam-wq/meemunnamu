import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { FoundationApiService } from '../../core/services/foundation-api.service';
import { Program, ActivityEvent, ImpactMetric, GalleryImage, Story } from '../../core/models/foundation.models';
import { ProgramCardComponent } from '../../shared/components/program-card/program-card.component';
import { EventCardComponent } from '../../shared/components/event-card/event-card.component';
import { CtaBannerComponent } from '../../shared/components/cta-banner/cta-banner.component';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    NzIconModule,
    ProgramCardComponent,
    EventCardComponent,
    CtaBannerComponent
  ],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  private api = inject(FoundationApiService);
  foundation = this.api.getFoundationInfo();

  featuredPrograms: Program[] = [];
  recentEvents: ActivityEvent[] = [];
  impactMetrics: ImpactMetric[] = [];
  galleryPreview: GalleryImage[] = [];
  featuredStories: Story[] = [];

  coreValues = [
    {
      title: 'Empathy in Action',
      telugu: 'సేవా భావం',
      desc: 'Going beyond words to actively stand with communities in times of hardship and adversity.',
      icon: 'heart',
      color: 'orange'
    },
    {
      title: 'Education for All',
      telugu: 'విద్యా వికాసం',
      desc: 'Ensuring financial hardship never denies a talented child their right to complete their education.',
      icon: 'read',
      color: 'primary'
    },
    {
      title: 'Dignified Healthcare',
      telugu: 'ఆరోగ్య రక్ష',
      desc: 'Bringing preventive screening, emergency medical aid, and blood donor support to the grassroots.',
      icon: 'medicine-box',
      color: 'green'
    },
    {
      title: 'Ecological Care',
      telugu: 'హరిత సంకల్పం',
      desc: 'Nurturing trees and fostering clean, sustainable practices for our collective future.',
      icon: 'environment',
      color: 'teal'
    }
  ];

  ngOnInit(): void {
    this.api.getPrograms().subscribe(progs => {
      this.featuredPrograms = progs.filter(p => p.featured).slice(0, 4);
    });

    this.api.getEvents().subscribe(evts => {
      this.recentEvents = evts.slice(0, 3);
    });

    this.api.getImpactMetrics().subscribe(metrics => {
      this.impactMetrics = metrics;
    });

    this.api.getGalleryImages().subscribe(imgs => {
      this.galleryPreview = imgs.slice(0, 6);
    });

    this.api.getStories().subscribe(stories => {
      this.featuredStories = stories.slice(0, 2);
    });
  }
}

