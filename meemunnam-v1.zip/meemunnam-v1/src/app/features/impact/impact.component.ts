import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { PageHeaderComponent } from '../../shared/components/page-header/page-header.component';
import { CtaBannerComponent } from '../../shared/components/cta-banner/cta-banner.component';
import { FoundationApiService } from '../../core/services/foundation-api.service';
import { ImpactMetric, Story } from '../../core/models/foundation.models';

@Component({
  selector: 'app-impact',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    NzIconModule,
    PageHeaderComponent,
    CtaBannerComponent
  ],
  templateUrl: './impact.component.html',
  styleUrls: ['./impact.component.scss']
})
export class ImpactComponent implements OnInit {
  private api = inject(FoundationApiService);

  metrics: ImpactMetric[] = [];
  stories: Story[] = [];

  breadcrumbs = [{ label: 'Our Impact' }];

  impactPillars = [
    {
      category: 'Education Support',
      telugu: 'విద్యా రంగంలో మార్పు',
      stats: '450+ Students Supported',
      details: 'Full annual tuition support, school backpacks, geometry kits, and higher secondary polytechnic / engineering coaching sponsorship.',
      icon: 'read',
      color: 'primary'
    },
    {
      category: 'Healthcare & Blood Relief',
      telugu: 'ఆరోగ్య రక్ష చర్యలు',
      stats: '1,800+ Diagnostic Screenings',
      details: '520+ Units of blood coordinated for government hospital blood banks, free cataract screenings, and monthly chronic medication subsidies.',
      icon: 'medicine-box',
      color: 'green'
    },
    {
      category: 'Community Relief & Shelter Care',
      telugu: 'సామాజిక సంక్షేమం',
      stats: '12,000+ Hydration Servings & Meals',
      details: '25-day heatwave Chalivendram centers, winter wool blanket distribution to 12 elder care homes and destitute shelters.',
      icon: 'heart',
      color: 'orange'
    },
    {
      category: 'Environmental Stewardship',
      telugu: 'హరిత సంరక్షణ',
      stats: '4,500+ Saplings Planted',
      details: 'Native shade & fruit trees planted across rural school grounds with 88% student adoption and monitored survival rate.',
      icon: 'environment',
      color: 'teal'
    }
  ];

  ngOnInit(): void {
    this.api.getImpactMetrics().subscribe(m => {
      this.metrics = m;
    });

    this.api.getStories().subscribe(s => {
      this.stories = s;
    });
  }
}

