import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { PageHeaderComponent } from '../../shared/components/page-header/page-header.component';
import { FoundationApiService } from '../../core/services/foundation-api.service';
import { FOUNDATION_INFO } from '../../core/services/foundation-data';

@Component({
  selector: 'app-donate',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NzIconModule,
    NzRadioModule,
    NzInputModule,
    NzButtonModule,
    NzSelectModule,
    PageHeaderComponent
  ],
  templateUrl: './donate.component.html',
  styleUrls: ['./donate.component.scss']
})
export class DonateComponent implements OnInit {
  private fb = inject(FormBuilder);
  private api = inject(FoundationApiService);

  foundation = FOUNDATION_INFO;
  donateForm!: FormGroup;

  isSubmitting = false;
  submissionSuccess = false;
  confirmationDetails?: { referenceId: string; receiptNumber: string; amount: number; cause: string };

  presetAmounts = [500, 1000, 2500, 5000, 10000];
  selectedAmount = 1000;
  isCustomAmount = false;

  causes = [
    { id: 'general', label: 'Where Needed Most (General Fund)' },
    { id: 'education', label: 'Student Scholarship & Study Kits' },
    { id: 'health', label: 'Emergency Medical & Blood Relief' },
    { id: 'community', label: 'Old Age Home & Destitute Nutrition' },
    { id: 'environment', label: 'Haritha Sankalpam Tree Plantation' }
  ];

  breadcrumbs = [{ label: 'Donate Online' }];

  ngOnInit(): void {
    this.initForm();
  }

  private initForm(): void {
    this.donateForm = this.fb.group({
      frequency: ['one_time', [Validators.required]],
      amount: [1000, [Validators.required, Validators.min(100)]],
      cause: ['general', [Validators.required]],
      donorName: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [Validators.required, Validators.pattern(/^[6-9]\d{9}$/)]],
      panNumber: ['', [Validators.pattern(/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/i)]],
      paymentMethod: ['upi', [Validators.required]],
      isAnonymous: [false]
    });
  }

  selectPreset(amt: number): void {
    this.selectedAmount = amt;
    this.isCustomAmount = false;
    this.donateForm.patchValue({ amount: amt });
  }

  onCustomAmountInput(): void {
    this.selectedAmount = 0;
    this.isCustomAmount = true;
  }

  onSubmit(): void {
    if (this.donateForm.invalid) {
      Object.values(this.donateForm.controls).forEach(control => {
        control.markAsTouched();
      });
      return;
    }

    this.isSubmitting = true;
    const formValue = this.donateForm.value;

    this.api.submitDonation(formValue).subscribe({
      next: res => {
        this.isSubmitting = false;
        this.submissionSuccess = true;
        this.confirmationDetails = {
          referenceId: res.data.referenceId,
          receiptNumber: res.data.receiptNumber,
          amount: formValue.amount,
          cause: formValue.cause
        };
      },
      error: () => {
        this.isSubmitting = false;
      }
    });
  }

  resetForm(): void {
    this.submissionSuccess = false;
    this.confirmationDetails = undefined;
    this.donateForm.reset({
      frequency: 'one_time',
      amount: 1000,
      cause: 'general',
      paymentMethod: 'upi',
      isAnonymous: false
    });
    this.selectedAmount = 1000;
    this.isCustomAmount = false;
  }
}
