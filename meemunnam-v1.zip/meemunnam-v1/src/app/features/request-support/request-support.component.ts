import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { PageHeaderComponent } from '../../shared/components/page-header/page-header.component';
import { FoundationApiService } from '../../core/services/foundation-api.service';

@Component({
  selector: 'app-request-support',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterLink,
    NzIconModule,
    PageHeaderComponent
  ],
  templateUrl: './request-support.component.html',
  styleUrls: ['./request-support.component.scss']
})
export class RequestSupportComponent implements OnInit {
  private fb = inject(FormBuilder);
  private api = inject(FoundationApiService);

  supportForm!: FormGroup;
  isSubmitting = false;
  submissionSuccess = false;
  assignedReference?: string;
  selectedFileName: string | null = null;

  breadcrumbs = [{ label: 'Request Support / Refer' }];

  ngOnInit(): void {
    this.supportForm = this.fb.group({
      applicantName: ['', [Validators.required, Validators.minLength(3)]],
      contactNumber: ['', [Validators.required, Validators.pattern(/^[6-9]\d{9}$/)]],
      email: ['', [Validators.email]],
      address: ['', [Validators.required, Validators.minLength(5)]],
      supportType: ['education', [Validators.required]],
      urgency: ['moderate', [Validators.required]],
      details: ['', [Validators.required, Validators.minLength(20)]],
      estimatedAmountNeeded: [null],
      privacyConsent: [false, [Validators.requiredTrue]]
    });
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedFileName = input.files[0].name;
    }
  }

  onSubmit(): void {
    if (this.supportForm.invalid) {
      Object.values(this.supportForm.controls).forEach(c => c.markAsTouched());
      return;
    }

    this.isSubmitting = true;
    this.api.submitSupportRequest(this.supportForm.value).subscribe({
      next: res => {
        this.isSubmitting = false;
        this.submissionSuccess = true;
        this.assignedReference = res.data.referenceNumber;
      },
      error: () => {
        this.isSubmitting = false;
      }
    });
  }

  resetForm(): void {
    this.submissionSuccess = false;
    this.assignedReference = undefined;
    this.selectedFileName = null;
    this.supportForm.reset({
      supportType: 'education',
      urgency: 'moderate',
      privacyConsent: false
    });
  }
}

