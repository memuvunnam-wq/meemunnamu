import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { PageHeaderComponent } from '../../shared/components/page-header/page-header.component';
import { CtaBannerComponent } from '../../shared/components/cta-banner/cta-banner.component';
import { FoundationApiService } from '../../core/services/foundation-api.service';
import { TeamMember, ImpactMetric } from '../../core/models/foundation.models';

@Component({
  selector: 'app-about',
  standalone: true,
  imports: [
    CommonModule,
    NzIconModule,
    PageHeaderComponent,
    CtaBannerComponent
  ],
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.scss']
})
export class AboutComponent implements OnInit {
  private api = inject(FoundationApiService);
  foundation = this.api.getFoundationInfo();

  teamMembers: TeamMember[] = [];
  metrics: ImpactMetric[] = [];

  breadcrumbs = [{ label: 'About Us' }];

  coreObjectives = [
    {
      title: 'Promote Meritorious Education',
      desc: 'Identify and sponsor talented youth from low-income families through scholarships, books, and career counseling.'
    },
    {
      title: 'Grassroots Medical & Blood Assistance',
      desc: 'Organize periodic rural diagnostic camps and maintain an active emergency donor registry across government hospitals.'
    },
    {
      title: 'Elderly & Destitute Welfare',
      desc: 'Provide steady grocery rations, warm blankets, and festival cheer to partner old-age care centers.'
    },
    {
      title: 'Environmental Conservation',
      desc: 'Conduct student-driven tree plantations and clean water advocacy to combat climate distress.'
    },
    {
      title: 'Skill Development & Women Autonomy',
      desc: 'Offer tailoring, computer skills, and small-enterprise training to help families achieve sustainable self-reliance.'
    },
    {
      title: 'Civic Duty & Rapid Relief',
      desc: 'Deploy volunteer teams during seasonal heatwaves, heavy floods, and public emergencies.'
    }
  ];

  ngOnInit(): void {
    this.api.getTeamMembers().subscribe(members => {
      this.teamMembers = members;
    });

    this.api.getImpactMetrics().subscribe(m => {
      this.metrics = m;
    });
  }
}
