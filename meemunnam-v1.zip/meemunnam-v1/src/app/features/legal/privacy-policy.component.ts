import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { PageHeaderComponent } from '../../shared/components/page-header/page-header.component';
import { FOUNDATION_INFO } from '../../core/services/foundation-data';

@Component({
  selector: 'app-privacy-policy',
  standalone: true,
  imports: [CommonModule, NzIconModule, PageHeaderComponent],
  templateUrl: './privacy-policy.component.html',
  styleUrls: ['./legal.component.scss']
})
export class PrivacyPolicyComponent {
  foundation = FOUNDATION_INFO;
  breadcrumbs = [{ label: 'Privacy Policy' }];
}
