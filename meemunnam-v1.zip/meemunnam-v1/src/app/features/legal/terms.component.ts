import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { PageHeaderComponent } from '../../shared/components/page-header/page-header.component';
import { FOUNDATION_INFO } from '../../core/services/foundation-data';

@Component({
  selector: 'app-terms',
  standalone: true,
  imports: [CommonModule, NzIconModule, PageHeaderComponent],
  templateUrl: './terms.component.html',
  styleUrls: ['./legal.component.scss']
})
export class TermsComponent {
  foundation = FOUNDATION_INFO;
  breadcrumbs = [{ label: 'Terms & Conditions' }];
}
