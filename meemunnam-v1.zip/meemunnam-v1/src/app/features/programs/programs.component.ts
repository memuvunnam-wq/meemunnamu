import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { PageHeaderComponent } from '../../shared/components/page-header/page-header.component';
import { ProgramCardComponent } from '../../shared/components/program-card/program-card.component';
import { EmptyStateComponent } from '../../shared/components/empty-state/empty-state.component';
import { CtaBannerComponent } from '../../shared/components/cta-banner/cta-banner.component';
import { FoundationApiService } from '../../core/services/foundation-api.service';
import { Program } from '../../core/models/foundation.models';

@Component({
  selector: 'app-programs',
  standalone: true,
  imports: [
    CommonModule,
    NzIconModule,
    PageHeaderComponent,
    ProgramCardComponent,
    EmptyStateComponent,
    CtaBannerComponent
  ],
  templateUrl: './programs.component.html',
  styleUrls: ['./programs.component.scss']
})
export class ProgramsComponent implements OnInit {
  private api = inject(FoundationApiService);

  allPrograms: Program[] = [];
  filteredPrograms: Program[] = [];
  activeCategory: string = 'all';

  categories = [
    { id: 'all', label: 'All Programs' },
    { id: 'education', label: 'Education & Students' },
    { id: 'health', label: 'Health & Medical' },
    { id: 'community', label: 'Community Welfare' },
    { id: 'environment', label: 'Environment & Green' },
    { id: 'skills', label: 'Skill Development' },
    { id: 'social', label: 'Social Responsibility' }
  ];

  breadcrumbs = [{ label: 'Our Programs' }];

  ngOnInit(): void {
    this.api.getPrograms().subscribe(programs => {
      this.allPrograms = programs;
      this.filterPrograms(this.activeCategory);
    });
  }

  filterPrograms(categoryId: string): void {
    this.activeCategory = categoryId;
    if (categoryId === 'all') {
      this.filteredPrograms = [...this.allPrograms];
    } else {
      this.filteredPrograms = this.allPrograms.filter(p => p.category === categoryId);
    }
  }
}
