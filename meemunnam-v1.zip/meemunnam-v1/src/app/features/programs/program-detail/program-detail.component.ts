import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { PageHeaderComponent } from '../../../shared/components/page-header/page-header.component';
import { CtaBannerComponent } from '../../../shared/components/cta-banner/cta-banner.component';
import { EventCardComponent } from '../../../shared/components/event-card/event-card.component';
import { FoundationApiService } from '../../../core/services/foundation-api.service';
import { Program, ActivityEvent } from '../../../core/models/foundation.models';

@Component({
  selector: 'app-program-detail',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    NzIconModule,
    PageHeaderComponent,
    CtaBannerComponent,
    EventCardComponent
  ],
  templateUrl: './program-detail.component.html',
  styleUrls: ['./program-detail.component.scss']
})
export class ProgramDetailComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private api = inject(FoundationApiService);

  program?: Program;
  relatedEvents: ActivityEvent[] = [];
  isLoading = true;
  breadcrumbs: { label: string; url?: string }[] = [];

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const slug = params.get('slug');
      if (slug) {
        this.loadProgram(slug);
      }
    });
  }

  private loadProgram(slug: string): void {
    this.isLoading = true;
    this.api.getProgramBySlug(slug).subscribe(p => {
      this.program = p;
      this.isLoading = false;
      if (p) {
        this.breadcrumbs = [
          { label: 'Programs', url: '/programs' },
          { label: p.title }
        ];

        // Fetch related events
        this.api.getEvents().subscribe(evts => {
          this.relatedEvents = evts.filter(e =>
            p.relatedEventSlugs?.includes(e.slug) || e.relatedProgramSlug === p.slug
          );
        });
      }
    });
  }
}

