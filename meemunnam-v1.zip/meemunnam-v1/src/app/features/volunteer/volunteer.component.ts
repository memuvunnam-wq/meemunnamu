import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzCheckboxModule } from 'ng-zorro-antd/checkbox';
import { PageHeaderComponent } from '../../shared/components/page-header/page-header.component';
import { FoundationApiService } from '../../core/services/foundation-api.service';

@Component({
  selector: 'app-volunteer',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterLink,
    NzIconModule,
    NzCheckboxModule,
    PageHeaderComponent
  ],
  templateUrl: './volunteer.component.html',
  styleUrls: ['./volunteer.component.scss']
})
export class VolunteerComponent implements OnInit {
  private fb = inject(FormBuilder);
  private api = inject(FoundationApiService);

  volunteerForm!: FormGroup;
  isSubmitting = false;
  submissionSuccess = false;
  assignedId?: string;

  availableInterests = [
    { id: 'education', label: 'Student Mentoring & Teaching' },
    { id: 'medical', label: 'Medical Camp Coordination & Blood Drives' },
    { id: 'community', label: 'Elderly Home Care & Food Distribution' },
    { id: 'environment', label: 'Tree Plantation & Environmental Drives' },
    { id: 'digital', label: 'Photography, Design & Social Media' },
    { id: 'logistics', label: 'Event Logistics & Emergency Response' }
  ];

  selectedInterests: string[] = ['education'];

  breadcrumbs = [{ label: 'Volunteer With Us' }];

  ngOnInit(): void {
    this.volunteerForm = this.fb.group({
      fullName: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      phone: ['', [Validators.required, Validators.pattern(/^[6-9]\d{9}$/)]],
      city: ['', [Validators.required]],
      availability: ['weekends', [Validators.required]],
      skillsExperience: [''],
      message: [''],
      privacyConsent: [false, [Validators.requiredTrue]]
    });
  }

  toggleInterest(id: string): void {
    if (this.selectedInterests.includes(id)) {
      this.selectedInterests = this.selectedInterests.filter(i => i !== id);
    } else {
      this.selectedInterests.push(id);
    }
  }

  onSubmit(): void {
    if (this.volunteerForm.invalid || this.selectedInterests.length === 0) {
      Object.values(this.volunteerForm.controls).forEach(c => c.markAsTouched());
      return;
    }

    this.isSubmitting = true;
    const data = {
      ...this.volunteerForm.value,
      interests: this.selectedInterests
    };

    this.api.submitVolunteer(data).subscribe({
      next: res => {
        this.isSubmitting = false;
        this.submissionSuccess = true;
        this.assignedId = res.data.id;
      },
      error: () => {
        this.isSubmitting = false;
      }
    });
  }

  resetForm(): void {
    this.submissionSuccess = false;
    this.assignedId = undefined;
    this.volunteerForm.reset({
      availability: 'weekends',
      privacyConsent: false
    });
    this.selectedInterests = ['education'];
  }
}

