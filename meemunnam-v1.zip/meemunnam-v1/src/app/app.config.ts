import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter, withComponentInputBinding, withInMemoryScrolling } from '@angular/router';
import { provideHttpClient, withFetch, withInterceptors } from '@angular/common/http';
import { apiInterceptor } from './core/interceptors/api.interceptor';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { provideNzI18n, en_US } from 'ng-zorro-antd/i18n';
import { registerLocaleData } from '@angular/common';
import en from '@angular/common/locales/en';

import { routes } from './app.routes';
import { provideNzIcons } from 'ng-zorro-antd/icon';
import {
  HeartOutline,
  ReadOutline,
  MedicineBoxOutline,
  EnvironmentOutline,
  TeamOutline,
  BulbOutline,
  MenuOutline,
  CloseOutline,
  PhoneOutline,
  MailOutline,
  ArrowRightOutline,
  CoffeeOutline,
  CheckCircleOutline,
  QuestionCircleOutline,
  ShareAltOutline,
  DownloadOutline,
  CalendarOutline,
  UserOutline,
  GlobalOutline,
  BankOutline,
  SafetyCertificateOutline,
  SearchOutline,
  FileTextOutline,
  ClockCircleOutline,
  BookOutline,
  SmileOutline,
  AuditOutline,
  QrcodeOutline,
  CreditCardOutline,
  ArrowLeftOutline,
  HomeOutline
} from '@ant-design/icons-angular/icons';

registerLocaleData(en);

const icons = [
  HeartOutline,
  ReadOutline,
  MedicineBoxOutline,
  EnvironmentOutline,
  TeamOutline,
  BulbOutline,
  MenuOutline,
  CloseOutline,
  PhoneOutline,
  MailOutline,
  ArrowRightOutline,
  CoffeeOutline,
  CheckCircleOutline,
  QuestionCircleOutline,
  ShareAltOutline,
  DownloadOutline,
  CalendarOutline,
  UserOutline,
  GlobalOutline,
  BankOutline,
  SafetyCertificateOutline,
  SearchOutline,
  FileTextOutline,
  ClockCircleOutline,
  BookOutline,
  SmileOutline,
  AuditOutline,
  QrcodeOutline,
  CreditCardOutline,
  ArrowLeftOutline,
  HomeOutline
];

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(
      routes,
      withComponentInputBinding(),
      withInMemoryScrolling({ scrollPositionRestoration: 'top', anchorScrolling: 'enabled' })
    ),
    provideHttpClient(withFetch(), withInterceptors([apiInterceptor])),
    provideAnimationsAsync(),
    provideNzI18n(en_US),
    provideNzIcons(icons)
  ]
};
