import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';

@Component({
  selector: 'app-cta-banner',
  standalone: true,
  imports: [CommonModule, RouterLink, NzIconModule],
  templateUrl: './cta-banner.component.html',
  styleUrls: ['./cta-banner.component.scss']
})
export class CtaBannerComponent {
  @Input() title: string = 'Together We Can Make a Lasting Difference';
  @Input() subtitle: string = 'Your generosity fuels education for underprivileged students, vital medical assistance, and compassionate community relief across Andhra Pradesh and Telangana.';
  @Input() primaryBtnText: string = 'Donate Now';
  @Input() primaryBtnLink: string = '/donate';
  @Input() secondaryBtnText: string = 'Join as a Volunteer';
  @Input() secondaryBtnLink: string = '/volunteer';
}

