import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NzIconModule } from 'ng-zorro-antd/icon';

@Component({
  selector: 'app-empty-state',
  standalone: true,
  imports: [CommonModule, NzIconModule],
  template: `
    <div class="mvf-empty-state">
      <div class="mvf-empty-icon">
        <span nz-icon [nzType]="icon" nzTheme="outline"></span>
      </div>
      <h4 class="mvf-empty-title">{{ title }}</h4>
      <p class="mvf-empty-text">{{ message }}</p>
      <button *ngIf="actionLabel" type="button" class="mvf-btn mvf-btn-primary mvf-btn-sm" (click)="action.emit()">
        {{ actionLabel }}
      </button>
    </div>
  `,
  styles: [`
    @use '../../../../styles/variables' as *;
    .mvf-empty-state {
      text-align: center;
      padding: 48px 24px;
      background: $mvf-color-white;
      border-radius: $mvf-radius-lg;
      border: 1px dashed $mvf-color-border;
      margin: 24px 0;

      .mvf-empty-icon {
        font-size: 42px;
        color: $mvf-color-text-muted;
        margin-bottom: 12px;
      }
      .mvf-empty-title {
        font-size: 1.125rem;
        font-weight: 700;
        color: $mvf-color-text-primary;
        margin-bottom: 6px;
      }
      .mvf-empty-text {
        font-size: 0.875rem;
        color: $mvf-color-text-secondary;
        max-width: 420px;
        margin: 0 auto 16px auto;
      }
    }
  `]
})
export class EmptyStateComponent {
  @Input() icon: string = 'search';
  @Input() title: string = 'No results found';
  @Input() message: string = 'Try adjusting your search terms or filter criteria.';
  @Input() actionLabel?: string;
  @Output() action = new EventEmitter<void>();
}

