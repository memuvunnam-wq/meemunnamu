import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { Program } from '../../../core/models/foundation.models';

@Component({
  selector: 'app-program-card',
  standalone: true,
  imports: [CommonModule, RouterLink, NzIconModule],
  templateUrl: './program-card.component.html',
  styleUrls: ['./program-card.component.scss']
})
export class ProgramCardComponent {
  @Input({ required: true }) program!: Program;
}

