# Memu Vunnam Foundation (మేము ఉన్నాం ఫౌండేషన్) — Official NGO Website

> **Motto:** *"Together We Support. Together We Transform Lives."*  
> **Telugu:** *"తోడుగా మేము... బాసటగా సమాజం కోసం"*

A modern, responsive, high-performance, and accessible web portal built with **Angular 19**, **NG-ZORRO (Ant Design)**, and **SCSS** for the **Memu Vunnam Foundation**.

---

## 1. Project Overview

The website provides a complete digital presence inspired by the information architecture of community welfare platforms (referencing [meemunnamu.org](https://www.meemunnamu.org)), redesigned with a clean, trustworthy, and modern visual identity centered around the official **Memu Vunnam Foundation** branding badge.

### Core Focus Areas & Programs
1. **Education & Student Support:** Sponsoring tuition, school bags, and mentorship for underprivileged meritorious students.
2. **Health & Medical Assistance:** Free health check-up camps, voluntary blood donation networks, and emergency medical aid.
3. **Community Welfare & Relief:** Old age home sustenance, winter blanket drives, and seasonal heatwave Chalivendram centers.
4. **Environmental Awareness & Greenery:** Haritha Sankalpam tree plantation with student adoption oaths.
5. **Skill Development & Youth Empowerment:** Vocational training, tailoring, and digital literacy.
6. **Social Responsibility:** Civic awareness rallies, road safety, and disaster volunteerism.

---

## 2. Technology Stack & Architecture

- **Framework:** Angular 19 (Standalone Components, Signals, Modern Control Flow `@if` / `@for`)
- **UI Component Library:** NG-ZORRO Ant Design v19 (`ng-zorro-antd`)
- **Iconography:** `@ant-design/icons-angular` (Tree-shaken SVG icon registry)
- **Styling Architecture:** 100% SCSS with strict BEM-inspired naming prefixed with `mvf-`
  - `src/styles/_variables.scss` (Design tokens: primary blue `#0755A5`, deep navy `#123E7A`, hope green `#20A83B`, orange `#FF7900`)
  - `src/styles/_mixins.scss` (Responsive breakpoints, flexbox helpers, cards, focus rings)
  - `src/styles/_typography.scss` (Google Fonts: Plus Jakarta Sans & Noto Sans Telugu)
  - `src/styles/_utilities.scss` (Grid system, badges, container constraints)
  - `src/styles/_components.scss` (Reusable buttons, banners, statistics, empty states)
- **Language:** TypeScript 5.7 (Strict mode enabled)
- **Routing:** Angular Router with route-level lazy loading (`loadComponent`), top scroll restoration, and component input binding
- **Forms:** Reactive Forms (`FormGroup`, `FormControl`) with custom validation patterns
- **HTTP Client:** Angular `provideHttpClient(withFetch(), withInterceptors([apiInterceptor]))`
- **Backend Readiness:** Fully prepared for future Node.js REST API & MySQL relational schema integration

---

## 3. Implemented Routes & Pages

| # | Route | Page Description |
|---|---|---|
| 1 | `/` | **Home:** Hero with official logo badge, mission, key pillars, featured programs, stats, recent activities, stories, and CTAs. |
| 2 | `/about` | **About Us:** Genesis, history, mission, vision, core values, objectives, trustees/leadership, and compliance details. |
| 3 | `/programs` | **Our Programs:** All 6 initiatives with category filtering pills and program cards. |
| 4 | `/programs/:slug` | **Program Detail:** Dynamic route displaying objectives, ground activities, beneficiaries, verified impact, and related drives. |
| 5 | `/activities` | **Activities & Events:** Keyword search, category & status filters (upcoming, recent, past archives), and responsive cards. |
| 6 | `/activities/:slug` | **Activity Detail:** Dynamic event page with objectives, drive impact, location metadata, and photo gallery. |
| 7 | `/gallery` | **Photo Gallery:** Multi-category image grid with interactive Lightbox Modal preview (`nz-modal`). |
| 8 | `/impact` | **Our Impact:** Documented milestones, pillar-wise metrics, 100% transparency statement, and report download options. |
| 9 | `/donate` | **Donate Online:** One-time / monthly selector, preset amounts (₹500-₹10,000), custom amount, donor form, official bank details, UPI ID, and provisional receipt confirmation. |
| 10 | `/volunteer` | **Volunteer With Us:** Comprehensive registration form (interests multi-select, availability, skills, and privacy consent). |
| 11 | `/request-support` | **Refer / Request Support:** Beneficiary intake portal with urgency classification, situation explanation, file upload interface, and tracking reference number. |
| 12 | `/stories` | **News & Stories:** Inspiring field updates, search filters, and article cards. |
| 13 | `/stories/:slug` | **Story Detail:** Detailed narrative reader with author metadata and consent notice. |
| 14 | `/contact` | **Contact Us:** Verified contact cards, operational hours, social media links, map placeholder, and reactive inquiry form. |
| 15 | `/faq` | **FAQ:** Accessible accordion panels (`nz-collapse`) categorized by general, donations, volunteering, and support. |
| 16 | `/privacy-policy` | **Privacy Policy:** Formal NGO data governance, collection, and retention statement. |
| 17 | `/terms` | **Terms & Conditions:** Website terms, non-profit donation rules, and legal jurisdiction. |
| 18 | `**` | **404 Not Found:** Branded error page with recovery navigation links. |

---

## 4. Getting Started & Development

### Prerequisites
- Node.js 20.x or 22.x LTS
- npm 10.x+

### Installation
```bash
# Clone the repository and navigate into the workspace
git clone <repo-url>
cd meemunnam

# Install all dependencies (Angular 19, NG-ZORRO v19, CDK)
npm install
```

### Local Development Server
```bash
# Start local development server on http://localhost:4200
npm start
```
Open `http://localhost:4200` in your web browser. The app will automatically reload whenever you modify any source files.

### Building for Production
```bash
npm run build
```
The optimized production bundle will be output to `dist/memu-vunnam-foundation/browser/`.

---

## 5. Backend & Database Integration Readiness

All data interactions are centralized within `src/app/core/services/foundation-api.service.ts` using typed models from `src/app/core/models/foundation.models.ts`.

### Future Node.js REST API Architecture
To connect a live Node.js / Express or NestJS backend:
1. Update `src/environments/environment.ts`:
   ```typescript
   export const environment = {
     production: false,
     apiUrl: 'http://localhost:5000/api', // Your Node.js server
     useMockData: false // Switch from mock delays to live HTTP requests
   };
   ```
2. The frontend expects standard RESTful endpoints:
   - `GET /api/programs` & `GET /api/programs/:slug`
   - `GET /api/events` & `GET /api/events/:slug`
   - `GET /api/gallery`
   - `GET /api/stories` & `GET /api/stories/:slug`
   - `POST /api/volunteer`
   - `POST /api/support-request`
   - `POST /api/donations`
   - `POST /api/contact`

### Future MySQL Schema Mapping
The data models directly map to relational tables:
- `programs` (`id`, `slug`, `title`, `telugu_title`, `description`, `category`, `image_url`, `beneficiaries`, `impact`)
- `activities` (`id`, `slug`, `title`, `date`, `location`, `status`, `program_id`, `results_impact`)
- `donations` (`id`, `reference_id`, `receipt_no`, `donor_name`, `email`, `phone`, `pan_number`, `amount`, `payment_method`, `created_at`)
- `volunteer_applications` (`id`, `full_name`, `email`, `phone`, `city`, `interests`, `availability`, `status`)
- `support_requests` (`id`, `reference_number`, `applicant_name`, `contact_number`, `support_type`, `urgency`, `details`, `status`)

---

## 6. Official Details Required Before Launch

The website has been built with clean, configurable data stores (`src/app/core/services/foundation-data.ts`). Before public launch, the foundation leadership should supply and verify the following official details:

1. **Statutory Registration:** Exact Society/Trust Registration Number, Date of Registration, and NGO Darpan ID.
2. **Tax Exemption:** 80G and 12A Certificate registration numbers and validity periods.
3. **Official Banking Credentials:** Final State Bank of India account number, IFSC code, and dedicated UPI VPA (e.g., `memuvunnam@sbi`).
4. **Official Headquarters:** Verified physical address, pin code, and Google Maps location embed URL.
5. **Board of Trustees:** Official roster of trustees with confirmed titles, high-resolution photographs, and short bios.
6. **Social Media Accounts:** Official URLs for Instagram, Facebook, YouTube, LinkedIn, and X (Twitter).
7. **Legal Counsel Review:** Sign-off on the draft Privacy Policy (`/privacy-policy`) and Terms of Service (`/terms`).
