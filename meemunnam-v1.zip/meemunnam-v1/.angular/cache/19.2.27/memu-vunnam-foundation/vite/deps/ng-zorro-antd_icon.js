import {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
} from "./chunk-QGKIOQ6Y.js";
import "./chunk-2SJ2DHYL.js";
import "./chunk-L3FG2H6S.js";
import "./chunk-UR7ZDK42.js";
import "./chunk-4AH7WMHY.js";
import "./chunk-FECPQMV6.js";
import "./chunk-WL33A23K.js";
import "./chunk-PN5HWABK.js";
import "./chunk-RDLUSYUK.js";
import "./chunk-FDLDX6DK.js";
import "./chunk-WPBYGH2V.js";
import "./chunk-NNMCRNBG.js";
import "./chunk-WDMUDEB6.js";
export {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService,
  provideNzIcons,
  provideNzIconsPatch
};
